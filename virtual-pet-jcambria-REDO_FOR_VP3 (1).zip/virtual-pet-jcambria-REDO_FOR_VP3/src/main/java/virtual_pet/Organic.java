package virtual_pet;

public class Organic extends VirtualPet {


    public Organic(String name, int hunger, int thirst, int boredom, int cleanliness) {
        super(name);
    }


}
