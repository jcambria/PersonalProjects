package virtual_pet;

final public class RoboticDog extends RoboticPet implements Walks {
    public RoboticDog(String name, int oil, int batteryPower, int boredom) {
        super(name, oil, batteryPower, boredom);

    }

    public void walk() {

    }


}
