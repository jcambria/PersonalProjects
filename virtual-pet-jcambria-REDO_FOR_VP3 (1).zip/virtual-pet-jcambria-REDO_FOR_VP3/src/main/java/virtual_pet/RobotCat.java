package virtual_pet;

final class RobotCat extends RoboticPet implements Walks {
    public RobotCat(String name, int oil, int batteryPower, int boredom) {
        super(name, oil, batteryPower, boredom);
    }

}
