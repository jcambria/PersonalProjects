package virtual_pet;

public class Cat extends Organic {
    public Cat(String name, int hunger, int thirst, int boredom, int cleanliness) {
        super(name, hunger, thirst, boredom, cleanliness);
    }
}
