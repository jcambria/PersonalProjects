package virtual_pet;

public interface Walks {
    void walk();

    void tick();
}
