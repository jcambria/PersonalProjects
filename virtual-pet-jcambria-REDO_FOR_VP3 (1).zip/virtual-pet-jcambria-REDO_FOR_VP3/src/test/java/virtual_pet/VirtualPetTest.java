//package virtual_pet;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

//public class VirtualPetTest {
//
//    @Test
//    void getThirst() {
//        VirtualPet underTest = new VirtualPet("", "", "");
//        assertEquals(5, underTest.getThirst());
//    }
//
//    @Test
//    void getHunger() {
//        VirtualPet underTest = new VirtualPet("", "", "");
//        assertEquals(5, underTest.getHunger());
//    }
//
//    @Test
//    void getHungerAfterPlay() {
//        VirtualPet underTest = new VirtualPet("", "", "");
//        underTest.getAfterPlay();
//        assertEquals(3, underTest.getHunger());
//    }
//}

